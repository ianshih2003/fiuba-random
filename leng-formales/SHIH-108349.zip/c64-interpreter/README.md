# Commodore 64 Basic V2 Interpreter


## Usage

* `lein run`: Run in interactive mode
* `lein test`: Run tests

### Executing Files
* Run `lein run`
* Type `LOAD {file_name}`
* Type `RUN`