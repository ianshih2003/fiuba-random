(ns c64-interpreter.core-test
  (:require [clojure.test :refer :all]
            [c64-interpreter.core :refer :all]))

(deftest operador?-test
  (testing "Prueba de la funcion: operador?"
    (is (= true (operador? '+)))
    (is (= true (operador? (symbol "+"))))
    (is (= false (operador? (symbol "%"))))
    (is (= false (operador? (symbol "a"))))
    (is (= true (operador? (symbol "<>"))))))

(deftest invalidar-test
  (testing "Prueba de la funcion: invalidar"
    (is (= '+ (invalidar '+)))
    (is (= (symbol "+") (invalidar (symbol "+"))))
    (is (= nil (invalidar (symbol "%"))))
    (is (= (symbol "<>") (invalidar (symbol "<>"))))))

(deftest anular-invalidos-test
  (testing "Prueba de la funcion: anular-invalidos"
    (is (= (str '(IF X nil * Y < 12 THEN LET nil X = 0)) (str (anular-invalidos '(IF X & * Y < 12 THEN LET ! X = 0)))))
    (is (= '("MUNDO") (anular-invalidos '("MUNDO"))))
    (is (= '(")") (anular-invalidos '(")"))))
    (is (= '(REM test) (anular-invalidos '(REM test))))
    (is (= '(N,N) (anular-invalidos '(N,N))))))

(deftest variable-float?-test
  (testing "Prueba de la funcion: variable-float?"
    (is (= true (variable-float? 'X)))
    (is (= false (variable-float? 'X$)))
    (is (= false (variable-float? 'X%)))
    (is (= true (variable-float? 'XY)))))

(deftest variable-integer?-test
  (testing "Prueba de la funcion: variable-integer?"
    (is (= false (variable-integer? 'X)))
    (is (= false (variable-integer? 'X$)))
    (is (= true (variable-integer? 'X%)))
    (is (= false (variable-integer? 'XY)))
    (is (= true (variable-integer? 'XY%)))
    (is (= false (variable-integer? '%)))))

(deftest variable-string?-test
  (testing "Prueba de la funcion: variable-string?"
    (is (= false (variable-string? 'X)))
    (is (= true (variable-string? 'X$)))
    (is (= false (variable-string? 'X%)))
    (is (= false (variable-string? 'XY)))
    (is (= true (variable-string? 'XY$)))
    (is (= false (variable-string? '$)))))


(deftest cargar-linea-test
  (testing "Prueba de la funcion: cargar-linea"
    (is (= '[((10 (PRINT X))) [:ejecucion-inmediata 0] [] [] [] 0 {}] (cargar-linea '(10 (PRINT X)) [() [:ejecucion-inmediata 0] [] [] [] 0 {}])))
    (is (= '[((10 (PRINT X)) (20 (X = 100))) [:ejecucion-inmediata 0] [] [] [] 0 {}]
           (cargar-linea '(20 (X = 100)) ['((10 (PRINT X))) [:ejecucion-inmediata 0] [] [] [] 0 {}])))
    (is (= '[((10 (PRINT X)) (15 (X = X + 1)) (20 (X = 100))) [:ejecucion-inmediata 0] [] [] [] 0 {}]
           (cargar-linea '(15 (X = X + 1)) ['((10 (PRINT X)) (20 (X = 100))) [:ejecucion-inmediata 0] [] [] [] 0 {}])))
    (is (= '[((10 (PRINT X)) (15 (X = X - 1)) (20 (X = 100))) [:ejecucion-inmediata 0] [] [] [] 0 {}]
           (cargar-linea '(15 (X = X - 1)) ['((10 (PRINT X)) (15 (X = X + 1)) (20 (X = 100))) [:ejecucion-inmediata 0] [] [] [] 0 {}])))))

(deftest expandir-nexts-test
  (testing "Prueba de la funcion: expandir-nexts"
    (is (= '((NEXT A) (NEXT B))
           (expandir-nexts (list (list 'NEXT 'A (symbol ",") 'B)))))
    (is (= '((PRINT 1) (NEXT A) (NEXT B))
           (expandir-nexts (list '(PRINT 1) (list 'NEXT 'A (symbol ",") 'B)))))
    (is (= '((PRINT 1) (NEXT))
           (expandir-nexts (list '(PRINT 1) (list 'NEXT)))))
    (is (= (list '(FOR I = 1 TO 20 + SIN (A) * 18) '(PRINT " " (symbol ";")) '(NEXT A) '(NEXT B))
           (expandir-nexts (list '(FOR I = 1 TO 20 + SIN (A) * 18) '(PRINT " " (symbol ";")) (list 'NEXT 'A (symbol ",") 'B)))))))

(deftest contar-sentencias-test
  (testing "Prueba de la funcion: contar-sentencias"
    (is (= 2 (contar-sentencias 10 [(list '(10 (PRINT X) (PRINT Y)) '(15 (X = X + 1)) (list 20 (list 'NEXT 'I (symbol ",") 'J))) [10 1] [] [] [] 0 {}])))
    (is (= 1 (contar-sentencias 15 [(list '(10 (PRINT X) (PRINT Y)) '(15 (X = X + 1)) (list 20 (list 'NEXT 'I (symbol ",") 'J))) [10 1] [] [] [] 0 {}])))
    (is (= 2 (contar-sentencias 20 [(list '(10 (PRINT X) (PRINT Y)) '(15 (X = X + 1)) (list 20 (list 'NEXT 'I (symbol ",") 'J))) [10 1] [] [] [] 0 {}])))))

(deftest generar-error-test
  (testing "Prueba de la funcion: generar-error"
    (is (= "?SYNTAX  ERROR" (generar-error 16 [:ejecucion-inmediata 4])))
    (is (= "?ERROR DISK FULL" (generar-error "?ERROR DISK FULL" [:ejecucion-inmediata 4])))
    (is (= "?SYNTAX  ERROR IN 100" (generar-error 16 [100 3])))
    (is (= "?ERROR DISK FULL IN 100" (generar-error "?ERROR DISK FULL" [100 3])))))



(deftest desambiguar-test
  (testing "Prueba de la funcion: desambiguar"
    (is (= (list '-u 2 '* (symbol "(") '-u 3 '+ 5 '- (symbol "(") 2 '/ 7 (symbol ")") (symbol ")"))
           (desambiguar (list '- 2 '* (symbol "(") '- 3 '+ 5 '- (symbol "(") '+ 2 '/ 7 (symbol ")") (symbol ")")))))
    (is (= (list 'MID$ (symbol "(") 1 (symbol ",") 2 (symbol ")"))
           (desambiguar (list 'MID$ (symbol "(") 1 (symbol ",") 2 (symbol ")")))))

    (is (= (list 'MID3$ (symbol "(") 1 (symbol ",") 2 (symbol ",") 3 (symbol ")"))
           (desambiguar (list 'MID$ (symbol "(") 1 (symbol ",") 2 (symbol ",") 3 (symbol ")")))))

    (is (= (list 'MID3$ (symbol "(") 1 (symbol ",") '-u 2 '+ 'K (symbol ",") 3 (symbol ")"))
           (desambiguar (list 'MID$ (symbol "(") 1 (symbol ",") '- 2 '+ 'K (symbol ",") 3 (symbol ")")))))))


(deftest extraer-data-test
  (testing "Prueba de la funcion: extraer-data"
    (is (= (list 'HOLA 'MUNDO 10 20)
           (extraer-data (list '(10 (PRINT X) (REM ESTE NO) (DATA 30)) '(20 (DATA HOLA)) (list 100 (list 'DATA 'MUNDO (symbol ",") 10 (symbol ",") 20))))))
    (is (= '()
           (extraer-data '(()))))))



(deftest preprocesar-expresion-test
  (testing "Prueba de la funcion: preprocesar-expresion"
    (is (= '("HOLA" + " MUNDO" + "")
           (preprocesar-expresion '(X$ + " MUNDO" + Z$) ['((10 (PRINT X))) [10 1] [] [] [] 0 '{X$ "HOLA"}])))
    (is (= '(5 + 0 / 2 * 0)
           (preprocesar-expresion '(X + . / Y% * Z) ['((10 (PRINT X))) [10 1] [] [] [] 0 '{X 5 Y% 2}])))
    (is (= '("MUNDO") (preprocesar-expresion '("MUNDO") ['((10 (PRINT X))) [10 1] [] [] [] 0 '{X 5 Y% 2}])))

    (is (= '(2) (preprocesar-expresion '(M%) ['((10 (PRINT X))) [10 1] [] [] [] 0 '{X 5 M% 2}])))))


(deftest precedencia-test
  (testing "Prueba de la funcion: precedencia"
    (is (= 1
           (precedencia 'OR)))
    (is (= 2
           (precedencia 'AND)))

    (is (= 6
           (precedencia '*)))

    (is (= 7
           (precedencia '-u)))

    (is (= 8
           (precedencia 'MID$)))

    (is (= 0
           (precedencia (symbol ","))))

    (is (= nil
           (precedencia "A")))))

(deftest aridad-test
  (testing "Prueba de la funcion: aridad"
    (is (= 0
           (aridad 'THEN)))
    (is (= 1
           (aridad 'SIN)))

    (is (= 2
           (aridad '*)))

    (is (= 3
           (aridad 'MID3$)))

    (is (= 2
           (aridad 'MID$)))

    (is (= 0
           (aridad "A")))))

(deftest eliminar-cero-decimal-test
  (testing "Prueba de la funcion: eliminar-cero-decimal"
    (is (= 1.5
           (eliminar-cero-decimal 1.5)))
    (is (= 1.5
           (eliminar-cero-decimal 1.50)))

    (is (= 1
           (eliminar-cero-decimal 1.0)))

    (is (= 'A
           (eliminar-cero-decimal 'A)))))

(deftest eliminar-cero-entero-test
  (testing "Prueba de la funcion: eliminar-cero-entero"
    (is (= nil
           (eliminar-cero-entero nil)))
    (is (= "A"
           (eliminar-cero-entero 'A)))

    (is (= " 0"
           (eliminar-cero-entero 0)))

    (is (= " 1.5"
           (eliminar-cero-entero 1.5)))

    (is (= " 1"
           (eliminar-cero-entero 1)))

    (is (= "-1"
           (eliminar-cero-entero -1)))

    (is (= "-1.5"
           (eliminar-cero-entero -1.5)))

    (is (= " .5"
           (eliminar-cero-entero 0.5)))

    (is (= "-.5"
           (eliminar-cero-entero -0.5)))

    (is (= "HOLA"
           (eliminar-cero-entero "HOLA")))

    (is (= " 100"
           (eliminar-cero-entero 100)))

    (is (= ")"
           (eliminar-cero-entero ")")))))

(deftest buscar-lineas-restantes-test
  (testing "Prueba de la funcion: buscar-lineas-restantes"
    (is (= nil
           (buscar-lineas-restantes [() [:ejecucion-inmediata 0] [] [] [] 0 {}])))
    (is (= nil
           (buscar-lineas-restantes ['((PRINT X) (PRINT Y)) [:ejecucion-inmediata 2] [] [] [] 0 {}])))

    (is (= (list '(10 (PRINT X) (PRINT Y)) '(15 (X = X + 1)) (list 20 (list 'NEXT 'I (symbol ",") 'J)))
           (buscar-lineas-restantes
            [(list '(10 (PRINT X) (PRINT Y)) '(15 (X = X + 1)) (list 20 (list 'NEXT 'I (symbol ",") 'J))) [10 2] [] [] [] 0 {}])))

    (is (= (list '(10 (PRINT Y)) '(15 (X = X + 1)) (list 20 (list 'NEXT 'I (symbol ",") 'J)))
           (buscar-lineas-restantes [(list '(10 (PRINT X) (PRINT Y)) '(15 (X = X + 1)) (list 20 (list 'NEXT 'I (symbol ",") 'J))) [10 1] [] [] [] 0 {}])))

    (is (= (list '(10) '(15 (X = X + 1)) (list 20 (list 'NEXT 'I (symbol ",") 'J)))
           (buscar-lineas-restantes [(list '(10 (PRINT X) (PRINT Y)) '(15 (X = X + 1)) (list 20 (list 'NEXT 'I (symbol ",") 'J))) [10 0] [] [] [] 0 {}])))

    (is (= (list '(15 (X = X + 1)) (list 20 (list 'NEXT 'I (symbol ",") 'J)))
           (buscar-lineas-restantes [(list '(10 (PRINT X) (PRINT Y)) '(15 (X = X + 1)) (list 20 (list 'NEXT 'I (symbol ",") 'J))) [15 1] [] [] [] 0 {}])))

    (is (= (list '(15) (list 20 (list 'NEXT 'I (symbol ",") 'J)))
           (buscar-lineas-restantes [(list '(10 (PRINT X) (PRINT Y)) '(15 (X = X + 1)) (list 20 (list 'NEXT 'I (symbol ",") 'J))) [15 0] [] [] [] 0 {}])))

    (is (= '((20 (NEXT I) (NEXT J)))
           (buscar-lineas-restantes [(list '(10 (PRINT X) (PRINT Y)) '(15 (X = X + 1)) (list 20 (list 'NEXT 'I (symbol ",") 'J))) [20 3] [] [] [] 0 {}])))

    (is (= '((20 (NEXT I) (NEXT J)))
           (buscar-lineas-restantes [(list '(10 (PRINT X) (PRINT Y)) '(15 (X = X + 1)) (list 20 (list 'NEXT 'I (symbol ",") 'J))) [20 2] [] [] [] 0 {}])))

    (is (= '((20 (NEXT J)))
           (buscar-lineas-restantes [(list '(10 (PRINT X) (PRINT Y)) '(15 (X = X + 1)) (list 20 (list 'NEXT 'I (symbol ",") 'J))) [20 1] [] [] [] 0 {}])))

    (is (= '((20))
           (buscar-lineas-restantes [(list '(10 (PRINT X) (PRINT Y)) '(15 (X = X + 1)) (list 20 (list 'NEXT 'I (symbol ",") 'J))) [20 0] [] [] [] 0 {}])))

    (is (= '((20))
           (buscar-lineas-restantes [(list '(10 (PRINT X) (PRINT Y)) '(15 (X = X + 1)) (list 20 (list 'NEXT 'I (symbol ",") 'J))) [20 -1] [] [] [] 0 {}])))

    (is (= nil
           (buscar-lineas-restantes [(list '(10 (PRINT X) (PRINT Y)) '(15 (X = X + 1)) (list 20 (list 'NEXT 'I (symbol ",") 'J))) [25 0] [] [] [] 0 {}])))

    (is (= '((160 (PRINT " " (symbol ";")) (NEXT A) (NEXT I))
             (170 (PRINT "*") (A = 8 * ATN (1)))
             (180 (PRINT INT (A * 100) / 100 , "   " (symbol ";") INT (SIN (A) * 100000) / 100000))
             (190 (FOR I = 1 TO 19) (PRINT " " (symbol ";")) (NEXT I) (PRINT "*")))
           (buscar-lineas-restantes ['((130 (LET A = 1))
                                       (160 (FOR I = 1 TO 20 + SIN (A) * 18) (PRINT " " (symbol ";")) (NEXT A , I))
                                       (170 (PRINT "*") (A = 8 * ATN (1)))
                                       (180 (PRINT INT (A * 100) / 100 , "   " (symbol ";") INT (SIN (A) * 100000) / 100000))
                                       (190 (FOR I = 1 TO 19) (PRINT " " (symbol ";")) (NEXT I) (PRINT "*")))
                                     [160 3] [] [] [] 0 {'A 1, 'I 1}])))
    (is (= '((160 (NEXT A) (NEXT I))
             (170 (PRINT "*") (A = 8 * ATN (1)))
             (180 (PRINT INT (A * 100) / 100 , "   " (symbol ";") INT (SIN (A) * 100000) / 100000))
             (190 (FOR I = 1 TO 19) (PRINT " " (symbol ";")) (NEXT I) (PRINT "*")))
           (buscar-lineas-restantes ['((130 (LET A = 1))
                                       (160 (FOR I = 1 TO 20 + SIN (A) * 18) (PRINT " " (symbol ";"))  (NEXT A , I))
                                       (170 (PRINT "*") (A = 8 * ATN (1)))
                                       (180 (PRINT INT (A * 100) / 100 , "   " (symbol ";") INT (SIN (A) * 100000) / 100000))
                                       (190 (FOR I = 1 TO 19) (PRINT " " (symbol ";")) (NEXT I) (PRINT "*")))
                                     [160 2] [] [] [] 0 {'A 1, 'I 1}])))))

(deftest continuar-linea-test
  (testing "Prueba de la funcion: continuar-linea"
    (is (= [nil [(list '(10 (PRINT X)) '(15 (X = X + 1)) (list 20 (list 'NEXT 'I (symbol ",") 'J))) [20 3] [] [] [] 0 {}]]
           (continuar-linea [(list '(10 (PRINT X)) '(15 (X = X + 1)) (list 20 (list 'NEXT 'I (symbol ",") 'J))) [20 3] [] [] [] 0 {}])))

    (is (= [:omitir-restante [(list '(10 (PRINT X)) '(15 (GOSUB 100) (X = X + 1)) (list 20 (list 'NEXT 'I (symbol ",") 'J))) [15 1] [] [] [] 0 {}]]
           (continuar-linea [(list '(10 (PRINT X)) '(15 (GOSUB 100) (X = X + 1)) (list 20 (list 'NEXT 'I (symbol ",") 'J))) [20 3] [[15 2]] [] [] 0 {}])))))

(deftest calcular-expresion-test
  (testing "Prueba de la funcion: continuar-linea"
    (is (= 7 (calcular-expresion '(X + 5) ['((10 (PRINT X))) [10 1] [] [] [] 0 '{X 2}])))))

(deftest ejecutar-asignacion-test
  (testing "Prueba de la funcion: ejecutar-asignacion"
    (is (= ['((10 (PRINT X))) [10 1] [] [] [] 0 '{X 5}]
           (ejecutar-asignacion '(X = 5) ['((10 (PRINT X))) [10 1] [] [] [] 0 '{}])))
    (is (= ['((10 (PRINT X))) [10 1] [] [] [] 0 '{X 5}]
           (ejecutar-asignacion '(X = 5) ['((10 (PRINT X))) [10 1] [] [] [] 0 '{X 2}])))

    (is (= ['((10 (PRINT X))) [10 1] [] [] [] 0 '{X 3}]
           (ejecutar-asignacion '(X = X + 1) ['((10 (PRINT X))) [10 1] [] [] [] 0 '{X 2}])))
    (is (= ['((10 (PRINT X))) [10 1] [] [] [] 0 '{X$ "HOLA MUNDO"}]
           (ejecutar-asignacion '(X$ = X$ + " MUNDO") ['((10 (PRINT X))) [10 1] [] [] [] 0 '{X$ "HOLA"}])))))

